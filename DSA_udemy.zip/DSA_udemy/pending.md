


pending topics:
 hashing
 search trees
 grpahs
 heap