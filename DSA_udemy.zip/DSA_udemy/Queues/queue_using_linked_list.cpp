#include<iostream>
using namespace std;
struct node{
    int data;
    node*next;
}*front=NULL,*rear = NULL;
void enqueue(int x){
    struct node *t = NULL;
    t = new node;
    if(t==NULL){
        cout<<"linked list full!"<<endl;
    }else{
        t->data = x;
        t->next = NULL;
        if(front==NULL){
            front =rear=t;
        }else{
            rear->next = t;
            rear = t;
        }
    }
}
int dequeue(){
    int x=-1;
    struct node *t;
    if(front==NULL){
        cout<<"linked list is empty"<<endl;
    }else{
        x=front->data;
        t= front;
        front =front->next;
        delete t;
    }
    return x;
}
void display(){
    struct node *p =front;
    while(p!=NULL){
        cout<<p->data<<" ";
        p=p->next;
    }
    cout<<endl;
}
int main()
{
    enqueue(10);
    enqueue(20);
    enqueue(30);
    enqueue(40);
    enqueue(50);
    enqueue(60);
    display();
    return 0;
}