#include<iostream>
using namespace std;
class Queue{
    private:
    int front;
    int rear;
    int size;
    int *Q;
    public:
    Queue(){front=rear=-1;size=10;Q = new int[size];}
    Queue(int size){
        this->size = size;
        front = rear =-1;
        Q = new int[this->size];
    }
    void enqueue(int item);
    int dequeue();
    void display();
};
void Queue::enqueue(int item){
    if(rear == size-1){
        cout<<"queue is full"<<endl;
    }else{ 
        rear++;
        Q[rear]= item;
    }
}
int Queue::dequeue(){
    int x=-1;
    if(rear==front){
        cout<<"queue is empty!"<<endl;
    }else{
        x=Q[front+1];
        front++;
    }
    return x;
}
void Queue:: display(){
    for(int i=front+1;i<=rear;i++){
        cout<<Q[i]<<" ";
    }
    cout<<endl;
}
int main()
{
    Queue q(5);
    q.enqueue(10);
    q.enqueue(20);
    q.enqueue(30);
    q.display();
    return 0;
}






































































// #include <iostream>
// using namespace std;

// struct queue {
//     int size;
//     int front;
//     int rear;
//     int *q;
// };
// void create(struct queue *q,int size){
//     q->size = size;
//     q->front = q->rear =-1;
//     q->q= new int[size];

// }
// void enqueue(struct queue *q,int x) {
//     if(q->rear==q->size-1){
//         cout<<"queue is full";
//     }else{
//         q->rear++;
//         q->q[q->rear] = x;
//     }
// }
// int dequeue(struct queue *q){
//     int x=-1;
//     if(q->rear == q->front){
//         cout<<"queue is empty";
//     }else{
//         q->front++;
//         x = q->q[q->front];
//     }
//     return x;
// }
// void display(struct queue q) {
//     if(q.front == q.rear){
//         cout<<"queue is empty!"<<endl;
//     }else{
//         for(int i=q.front+1;i<=q.rear;i++){
//             cout<<q.q[i]<<" ";
//         }
//     }
//     cout<<endl;
// }

// int main() {
//     struct queue q;
//     create(&q,5);

//     enqueue(&q,10);
//     enqueue(&q,20);
//     enqueue(&q,30);
//     enqueue(&q,50);
//     enqueue(&q,60);
//     enqueue(&q,70);
//     display(q);

//     delete[] q.q;
//     return 0;
// }
