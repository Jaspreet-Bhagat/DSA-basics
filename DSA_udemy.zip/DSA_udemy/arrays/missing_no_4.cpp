//when the array is unsorted
#include<iostream>
using namespace std;

int main()
{
    int size,a[20],b[20];
    cout<<"enter the size of the array:"<<endl;
    cin>>size;
    cout<<"Enter "<<size<<" elements in the array:"<<endl;
    for(int i=0;i<size;i++){
        cin>>a[i];
    }
    int max;
    for(int i=0;i<size;i++){
        if(a[0]<a[i]){
            a[0] = a[i];
            max = a[0];
        }
    }
    // cout<<"max:"<<max;
    cout<<"another array is:"<<endl;9
    for(int j=0;j<max;j++){
        b[j] = 0;
        // cout<<" "<<b[j];
    }
    for(int i=0;i<size;i++){
        
        if(a[i]== i)
            b[a[i]]++;
    }
    return 0;
}