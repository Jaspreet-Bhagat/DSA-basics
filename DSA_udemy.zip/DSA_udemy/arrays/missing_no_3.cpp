//multiple missing number
 #include<iostream>
using namespace std;

int main()
{
    int first,last;
    int loc;
    int a[]={6,7,8,9,11,12,15,16,17,18,19};
    first = a[0];
    int diff=first-0;
    cout<<"first:"<<first<<endl;
    last = a[10];
    cout<<"last:"<<last<<endl;
    for(int i=0;i<11;i++){
        if(a[i]-i != diff){
            cout<<"the difference is:"<<diff<<endl;
            while(diff<a[i]-i){
                cout<<"missing element is:"<<i+diff<<endl;
                diff++;
            }
        }
    }
    return 0;
}
