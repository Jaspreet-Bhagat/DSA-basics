#include<iostream>
using namespace std;
bool is_sorted(int a[],int size){
    for(int i=0;i<size-1;i++){
        if(a[i]>a[i+1]){
            return false;
        }
        return true;
    }

}
int main()
{
    int ch,size,a[20];
    cout<<"enter the size of array:";
    cin>>size;
    cout<<"enter "<<size<<"  elements in the array:"<<endl;
    for(int i=0;i<size;i++){
        cin>>a[i];
    }
    cout<<"-------You entered-----"<<endl;
    for(int i=0;i<size;i++){
        cout<<a[i];
    } 

    int j = is_sorted(a,size);
    if(j == true){
        cout<<"array is sorted!";
    }
    else{
        cout<<"array is not sorted!";
    }
    return 0;
}