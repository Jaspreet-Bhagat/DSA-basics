#include<iostream>
using namespace std;
class array{
    private:
    int size,choice,item,a,Delete;
    public:
    array(int sz){
        size = sz;
        a = new int[sz]
    }
    void display();
    void insert(int index);
    void Delete(int index);
};

void array::display(){
    for(int i=0;i<size;i++){
        cout<<a[i]<<" "<<endl;
    }
}
void array::insert(int index){
    if(index>0 && index<size){
        for(int i=0;i<size;i++){
            a[i+1]=a[i];
            size++;
        }

    }

}
void array::Delete(int index){
    if(index>0 && index<size){
        for(int i=0;i<size;i++){
            a[i]=a[i+1];
            size--;
        }

    }

}

int main()
{
    int n;
    cout<<"enter the size of the array:"<<endl;
    cin>>n;
    array obj(n);
    cout<<"enter "<<obj.size<<"elements in the array:"<<endl;
    for(int i=0;i<obj.size;i++){
        cin>>obj.a[i];
    }
    cout<<endl<<"1.Insert"<<endl<<"2.delete"<<endl<<"3.display"<<endl<<"4.exit"<<endl;
    cout<<"---------------------------------"<<endl;
    cout<<"enter your choice:"<<endl;
    cin>>obj.choice;
    while(1){
        switch(obj.choice){
            case 1:
            cout<<"enter the index you want to insert:"<<endl;
            cin>>obj.item;
            obj.insert(obj.item);
            break;
            case 2:
            cout<<"enter the index you need to delete:"<<endl;
            cin>>obj.Delete;
            obj.Delete(obj.Delete);
            break;
            case 3:
            obj.display();
            break;
            case 4:
            exit(1);
            break;
        }
    }


    
    return 0;
}