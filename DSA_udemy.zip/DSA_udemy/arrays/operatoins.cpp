#include<iostream>
using namespace std;
class operations{
    int a[20],size,index,item;
    public:
    int ch;

    void get_array();
    void get();
    void set();
    void max();
    void min();
    void sum();
    void avg();
};
void operations::get_array(){
    cout<<"enter the size of an array:";
    cin>>size;
    cout<<"enter "<<size <<" elements in the array:"<<endl;
    for(int i=0;i<size;i++){
        cin>>a[i];
    }

}
void operations::get(){
    cout<<"Enter the index you need to search:"<<endl;
    cin>>index;
    if(index>=0 && index<size){
        cout<<"the element at index "<<index<<" is "<<a[index]<<endl;
    }
    else{
        cout<<"enter a valid index"<<endl;
    }
}
void operations::set(){
    cout<<"enter the number you want to insert: "<<endl;
    cin>>item;
    cout<<"enter the index where you need to isnert the element:"<<endl;
    cin>>index;
    if(index>=0&&index<size){
        a[index]=item;
    }
    else{
        cout<<"enter a valid index"<<endl;
    }

    for(int i=0;i<size;i++){
        cout<<a[i]<<" ";
    }
}
void operations::max(){
    int max;
    max= a[0];
    for(int i=0;i<size;i++){
        if(a[i]>max){
            max = a[i];
        }
    }
    cout<<"the max element in the array is:"<< max<<endl;
    cout<<endl;
}
void operations::min(){
    int min;
    min= a[0];
    for(int i=0;i<size;i++){
        if(a[i]<min){
            min = a[i];
        }
    }
    cout<<"the min element in the array is:"<< min <<endl;
    cout<<endl;
}
void operations::sum(){
    int sum;
    sum= 0;
    for(int i=0;i<size;i++){
        sum = a[i];
    }
    cout<<"the sum of  element in the array is:"<< sum <<endl;
    cout<<endl;
}
void operations::avg(){
    int sum,avg;
    sum= 0;
    for(int i=0;i<size;i++){
        sum = a[i];
    }
    avg = sum/size;
    cout<<"the avg of  element in the array is:"<< avg <<endl;
    cout<<endl;
}

int main()
{
    operations obj;
    obj.get_array();
    while(obj.ch!=7){
    cout<<"Select from options:";
    cout<<"\nEnter 1 : GET \nEnter 2 : SET \nEnter 3 : MAX \nEnter 4 : MIN \nEnter 5 : SUM \nEnter 6 : AVG \nEnter 7 : Exit"<<endl;
    cin>>obj.ch;
        switch(obj.ch){
            case 1:
                obj.get();
                break;
            case 2:
                obj.set();
                break;
            case 3:
                obj.max();
                break;
            case 4:
                obj.min();
                break;
            case 5:
                obj.sum();
                break;
            case 6:
                obj.avg();
                break;
            case 7:
                break;
            default:
            cout<<"enter a valid choice!"<<endl;
            break;
        }
    }
    return 0;
}