//single_missing_element_in_sorted_array
//first n natural numbers
#include<iostream>
using namespace std;

int main()
{
    int n,s=0;
    int sum,diff; 
    int last;
    int a[] = {1,2,3,4,5,6,8,9,10,11,12};
    for(int i=0;i<11;i++){
        s = s+a[i];
    }
    cout<<s<<endl;
    last = a[10];
    cout<<last<<endl;
    sum = (last*(last+1))/2;
    cout<<sum<<endl;
    diff = sum-s;
    cout<<"the missing element is:"<<diff;
    return 0;
}
