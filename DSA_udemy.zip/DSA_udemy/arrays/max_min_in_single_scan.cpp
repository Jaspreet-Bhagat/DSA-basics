#include<iostream>
using namespace std;

int main()
{
    int a[]= {5,8,3,9,6,2,10,7,-1,4};
    int min =a[0];
    int max = a[0];
    for(int i=1;i<10;i++){
        if(a[i]<min){
            min = a[i];
        }
        else if(a[i]>max){
            max = a[i];
        }

    }
    cout<<"max ="<<max<<endl;
    cout<<"min ="<<min<<endl;
    return 0;
}