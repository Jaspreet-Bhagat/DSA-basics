//array starting from some other number other than 1 but the difference between them remains the same.
#include<iostream>
using namespace std;

int main()
{
    int first,last;
    int loc;
    int a[]={6,7,8,9,10,11,12,13,14,16,17};
    first = a[0];
    int diff=first-0;
    cout<<first<<endl;
    last = a[10];
    cout<<last<<endl;
    for(int i=0;i<11;i++){
        if(a[i]-i != diff){
            loc = i;
            cout<<loc<<endl;
            cout<<diff<<endl;
            cout<<"missing number is:"<<loc+diff;
            break; 
        }
    }
    return 0;
}