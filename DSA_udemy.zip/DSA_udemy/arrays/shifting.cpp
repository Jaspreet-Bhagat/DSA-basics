#include<iostream>
using namespace std;

int main()
{
    //left_shift;
    int size,a[20];
    cout<<"enter the size of the array:";
    cin>>size;
    cout<<"enter "<<size<<" elements in the array:(in a sorted order)"<<endl;
    for(int i=0;i<size;i++){
        cin>>a[i];
    }
    //left rotation
    int temp = a[0];
    for (int i = 0; i < size; i++)
    {
        a[i]=a[i+1];
    }
    a[size-1]=temp;
    cout<<"altered array is:"<<endl;
    for (int i = 0; i < size; i++)
    {

        cout<<a[i]<<" ";
    }
    

    return 0;
}