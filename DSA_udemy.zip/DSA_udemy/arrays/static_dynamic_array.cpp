#include<iostream>
#include<stdio.h>
#include<stdlib.h>
using namespace std;

int main()
{
    int n,a[20];
    //printing the array from the user:
    cout<<"enter the size of array:"<<endl;
    cin>>n;
    cout<<"Enter "<<n<<" number in the array"<<endl;
    for(int i =0;i<n;i++){
        scanf("%d\t",&a[i]);
    }
    printf("the static arrray is stored in stack and is as follows:");
    cout<<endl;
    for (int i = 0; i < n; i++)
    {
        cout<<a[i]<<" \t";

    }

    //dynamic array
    //we use pointer for accessing the memory through heap
    int *ptr;
    ptr = new int[n];
    ptr[0]=3;
    ptr[1]=4;
    ptr[2]=5;
    ptr[3]=6;
    ptr[4]=7;

    //ptr=(int *)malloc(n*sizeof(int));
    cout<<endl;
    printf("dynamic array");
    for(int j=0;j<n;j++){
        cout<<ptr[j]<<"\t";
    }  
    return 0;
}