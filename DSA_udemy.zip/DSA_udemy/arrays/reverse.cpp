#include<iostream>
using namespace std;
void swap(int ,int );
class reverse{
    int size, a[20],x[20];
    public:
    void get_array();
    void reverse_s();
};
void reverse::get_array(){
    cout<<"enter the size of an array:";
    cin>>size;
    cout<<"enter "<<size <<" elements in the array:"<<endl;
    for(int i=0;i<size;i++){
        cin>>a[i];
    }
}

void reverse::reverse_s(){
    int j=0;
    for(int i=size-1;i>=0;--i){
        x[j] = a[i];
        j++;
    }
    cout<<"the reversed array will be:"<<endl;
    for(int j=0;j<size;j++){
            cout<<x[j]<<" ";
    }

}


void reverse::reverse_s(){
    int temp;
    for(int i=0,j=size-1;i<j;i++,j--){
        temp = a[i];
        a[i] = a[j];
        a[j] = temp;
    }
    cout<<"the reversed array will be:"<<endl;
    for(int j=0;j<size;j++){
            cout<<a[j]<<" ";
    }
}
int main()
{
    reverse obj;
    obj.get_array();
    obj.reverse_s();
    return 0;
}