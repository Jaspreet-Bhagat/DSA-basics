#include<iostream>
using namespace std;
class searching{
    int a[20],size;
    public:
    int ch,item,loc=-1;
    void basic_info();
    void linear_search();
    int binary_search();
    void display();
};
void searching::basic_info(){
    cout<<"enter the size of the array:";
    cin>>size;
    cout<<"enter "<<size<<" elements in the array:(in a sorted order)"<<endl;
    for(int i=0;i<size;i++){
        cin>>a[i];
    }
}
void searching::display(){
    cout<<endl<<"---------array is as follows----------"<<endl;
    for(int j=0;j<size;j++){
        cout<<a[j]<<" ";
    }
}
void searching::linear_search(){
    int item,loc=0;
    // int count = 0;
    cout<<"enter the item you need to search: ";
    cin>>item;
    for(int j =0;j<size;j++){
        if(item==a[j]){
            loc =loc+j;
            // count++;
        }
    }
    if (loc!=0)
    cout<<item<<" is present at the loc "<<loc <<" in the array."<<endl;
    else
    cout<<item<<" is not present in the array";
}

int searching::binary_search(){
    cout<<"enter the item you need to search: ";
    cin>>item;
    int beg =0;
    int end = size-1;
    int mid;
    while(beg<=end){
        mid = (beg+end)/2;
        if(a[mid]==item){
            return mid;
        }
        else if(item<a[mid]){
            end = mid-1;
        }
        else{
            beg = mid+1;
        }
        }
        return loc;

}
int main()
{
    searching obj;
    int loc;
    obj.basic_info();
    obj.display();
    while(obj.ch!=3){
    cout<<endl<<"enter your choice:"<<endl;
    cout<<"\n enter 1: linear searching\n enter 2: binary search\n enter 3: Exit "<<endl;
    cin>>obj.ch;

    switch (obj.ch)
    {
    case 1:
        obj.linear_search();
        break;
    case 2:
        loc = obj.binary_search();
        if (loc!=-1)
        cout<<obj.item<<" is present at the loc "<<obj.loc <<" in the array."<<endl;
        else
        cout<<obj.item<<" is not present in the array";
        break;
    case 3:
        break;
    default:
        cout<<"enter a valid choice!";
        break;
    }
    }

    return 0;
}