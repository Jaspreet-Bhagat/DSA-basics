#include <iostream>
using namespace std;

class node {
public:
    int data;
    node* next;
};

class circular_linked_list {
    node* head = NULL;

public:
    circular_linked_list(int a[], int size);
    void insert(int index, int item);
    void display();
    int count();
};

circular_linked_list::circular_linked_list(int a[], int size) {
    node* temp, * last;
    head = new node;
    head->data = a[0];
    head->next = head;
    last = head;
    for (int i = 1; i < size; i++) {
        temp = new node;
        temp->data = a[i];
        temp->next = last->next;
        last->next = temp;
        last = temp;
    }
}

void circular_linked_list::display() {
    if (head == NULL) {
        cout << "List is empty." << endl;
        return;
    }

    node* p = head;
    do {
        cout << p->data << " ";
        p = p->next;
    } while (p != head);
}



int circular_linked_list::count() {
    int count = 0;
    if (head == NULL) {
        return count;
    }
    node* p = head;
    do {
        count++;
        p = p->next;
    } while (p != head);
    return count;
}

int main() {
    int a[] = { 2, 3, 4, 5, 6 };
    circular_linked_list obj(a, 5);
    obj.display();

    int nodeCount = obj.count();
    cout << "\nNumber of nodes: " << nodeCount << endl;

    return 0;
}
