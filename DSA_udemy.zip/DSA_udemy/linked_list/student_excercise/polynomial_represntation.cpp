#include<iostream>
using namespace std;
struct node {
    int coeff;
    int exp;
    struct node *next;
}*poly = NULL;
void create(){
    struct node *t,*last;
    int num;
    cout<<"enter the number of terms: "<<endl;
    cin>>num;
    cout<<"enter each term with coeff and exp"<<endl;
    for(int i=0;i<num;i++){
        t = new node;
        cin>>t->coeff;
        cin>>t->exp;
        t->next = NULL;
        if(poly == NULL){
            poly =last =t;   
        }else{
            last->next =t;
            last=t;
        }
    }
}
void display(struct node *p){
    while(p){
        cout<<p->coeff<<"*"<<p->exp<<"+";
        p=p->next;
    }
    cout<<endl;

}
long eval(Struct node *p,int x){
    long val;
    while(p){
        val+=p->coeff *pow(x,p->exp);
        p = p->next;
    }
    return val;
}
int main()
{
    create();
    display(poly);
    cout<<endl;
    cout<<val;
    return 0;
}