#include<iostream>
using namespace std;
struct node{
    int col_no;
    int item;
    int row_no;
    struct node *next;
};
struct sparse{
    int T_col;
    int T_row;
    int T_num;
    int *e;
};
int main()
{
    struct node *a;
    struct sparse obj;
    int size = obj.T_col
    a = new int[size];
    a[0] = new node;

    return 0;
}