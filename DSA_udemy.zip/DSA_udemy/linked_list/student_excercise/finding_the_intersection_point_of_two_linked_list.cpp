#include<iostream>
#include<cmath>
#include<stack>
using namespace std;
struct node{
    int data;
    struct node *next;
}*first = NULL ,*second = NULL;
void create1(int *a,int size){
    struct node *temp,*last;
    first = new node;
    first->data = a[0];
    first->next = NULL;
    last= first;
    for(int i=1;i<size;i++){
        temp = new node;
        temp->data = a[i];
        temp->next = NULL;
        last->next = temp;
        last =temp;
    }
}
void create2(int *a,int size){
    struct node *temp,*last;
    second = new node;
    second->data = a[0];
    second->next = NULL;
    last= second;
    for(int i=1;i<size;i++){
        temp = new node;
        temp->data = a[i];
        temp->next = NULL;
        last->next = temp;
        last =temp;
    }
}
void display(struct node *p){
    while(p!=NULL){
        cout<<p->data<<" ";
        p=p->next;
    }
}
void intersection_point(struct node *p,struct node *q){
    stack<node *>stk1;
    while(p!=NULL){
        stk1.push(p);
        p =p->next;
    }
    stack<node *>stk2;
    while(q!=NULL){
        stk2.push(q);
        q =q->next;
    }
    node *r;
    while (!stk1.empty() && !stk2.empty() && stk1.top()->data == stk2.top()->data) {
        r = stk1.top();
        stk1.pop();
        stk2.pop();
    }

    if (r != NULL) {
        cout <<endl<< "Intersection Point: " << r->data << endl;
    } else {
        cout << "No Intersection Point found." << endl;
    }
}
int main()
{
    int a[]={8,6,3,9,10,4,2,12};
    int b[]={20,30,40,10,4,2,12};
    create1(a,8);
    cout<<"first: "<<endl;
    display(first);
    create2(b,7);
    cout<<endl<<"second: "<<endl;
    display(second);
    intersection_point(first,second);
    return 0;
}