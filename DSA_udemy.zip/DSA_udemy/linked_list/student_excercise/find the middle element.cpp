
#include<iostream>
#include<ctime>
#include<cstdlib>

using namespace std;
struct node{
    int data;
    struct node *next;
}*first = NULL;
void create(int a[],int size){
    struct node *temp,*last;
    first = new node;
    first->data = a[0];
    first->next = NULL;
    // last->next = first;
    last = first;
    for(int i=1;i<size;i++){
        temp = new node;
        temp->data = a[i];
        temp->next = NULL;
        last->next = temp;
        last = temp;
    }
}
void display(struct node *p){
    cout<<endl;
    cout<<"the linked list of that array: "<<endl;
    while(p!=NULL){
        cout<<p->data<<"->";
        p = p->next;
    }
}
void get(int *a,int size){
    srand(time(nullptr));
    for(int i=0;i<size;i++){
        a[i] = rand()%100+1;
    }
    cout<<"the randomly generated array"<<endl;
    for(int i=0;i<size;i++){
        cout<<a[i]<<" ";
    }
}
void middle_node(struct node *p){
    struct node *q = NULL;

    q = p;
    while(q!=NULL && q->next !=NULL){//q->next != NULL, you are checking if q->next is not equal to NULL. However, this condition would skip the last node if the linked list has an odd number of nodes. The correct condition should be q != NULL to ensure that both q and q->next are not NULL.
        q=q->next->next;
        if(q){
            p = p->next;
        }
    }
    cout<<endl<<"the middle node of this linked list is :"<<endl;
    cout<<p->data;
}
int main()
{           
    int size = 8;
    int *a;
    int b[] = {8,6,3,9,10,4,2,12};
    a = new int[size];
    // get(b,size);
    create(b,size);
    display(first);
    middle_node(first);
    return 0;
}