#include<iostream>
using namespace std;
struct node{
    struct node *prev;
    int data;
    struct node *next;
}*first=NULL;


struct node *create(int a[],int size){
    struct node *temp,*last;
    first= new node;
    first->prev = NULL;
    first->data = a[0];
    first->next = NULL;
    last = first;
    for(int i=1;i<size;i++){
        temp = new node;
        temp->data = a[i];
        temp->prev = last;
        last->next = temp;
        last = temp;
    }
    return first;
}
void display(struct node *p){
    while(p){
        cout<<p->data<<" ";
        p = p->next;
    }
    cout<<endl;
}
int count(struct node *p){
    int count = 0;
    while(p){
        count++;
        p =p->next;
    }
    return count;
}
int main()
{
    int a[] = {10,20,30,40,50,60};
    create(a,6);
    display(first);
    cout<<endl;
    cout<<"count: "<<count(first);
    return 0;
}