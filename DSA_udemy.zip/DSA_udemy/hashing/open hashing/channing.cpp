#include<iostream>
using namespace std;
//linked list node
class node{
public:
int data;
node *next;
};
//hash table
class hashtable{
    public:
    node **HT;
    hashtable();
    int hash(int key);
    void insert(int key);
    int search(int key);
    ~hashtable();
};
hashtable::hashtable(){
    HT = new node *[10];
    fo(int i=0;i<10;i++){
        HT[i] = NULL;
    }
}
hashtable::~hashtable(){
    for(int i=0;i<10;i++){
        node*p = HT[i];
        while(HT[i]){
            HT[i] = HT[i]->next;
            delete p;
            p = HT[i];
        }
    }
    delete [] HT;
}
int hashtable::hash(int key){
    return key%10;
}
void hashtable::insert(int key){
    int hIdx = hash(key);
    node *t  = new node;
    t->data = key;
    t->next = NULL;
    if(HT[hIdx] == NULL){
        HT[hIdx] = t;
    }else{
        node *p = HT[hIdx];
        node *q = HT[hIdx];
        while(p &&p->data<key){
            q = p ;
            p = p->next;
        }
        if(q == HT[hIdx]){
            t->next = HT[hIdx];
            
        }
    }

}
int main()
{
    
    return 0;
}