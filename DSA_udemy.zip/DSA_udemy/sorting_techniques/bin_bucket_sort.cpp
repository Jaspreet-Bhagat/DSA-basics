#include<iostream>
using namespace std;
class node{
    public:
        int value;
        node *next;
};
void insert(node **ptrbins,int index){
    node *temp = new node;
    temp->value = index;
    temp->next = NULL;
    if(ptrbins[index]==NULL){
        ptrbins[index] = temp;
    }else{
        node *p =ptrbins[index];
        while(p->next!=NULL){
            p = p->next;
        }
        p->next = temp;
    }
}
int Delete(node **ptrbins,int index){
    node *p = ptrbins[index];
    ptrbins[index] = ptrbins[index]->next;
    int x = p->value;
    delete p;
    return x;
}
int Max(int A[],int n){
    int max = -32768;
    for (int i=0; i<n; i++){
        if (A[i] > max){
            max = A[i];
        }
    }
    return max;
}
void bin_sort(int a[],int n){
    int max = Max(a,n);
    node **bins = new node*[max+1];
    for(int i=0;i<n+1;i++){
        bins[i] = NULL;
    }
    for(int i=0;i<n;i++){
        insert(bins,a[i]);
    }
    int i=0;
    int j=0;
    while(i<max+1){
        while(bins[i]!=NULL){
            a[j++] = Delete(bins,i);
        }
        i++;
    }
    delete []bins;
}


int main()
{
    int a[] = {2, 5, 8, 12, 3, 6, 7, 10};
    int n = sizeof(a)/sizeof(a[0]);
    bin_sort(a,n);
    for(int i=0;i<n;i++){
        cout<<a[i]<<" ";
    }
    return 0;
}
