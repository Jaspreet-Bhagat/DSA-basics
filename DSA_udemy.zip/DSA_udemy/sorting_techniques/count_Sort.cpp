#include<iostream>
using namespace std;

int max(int a[], int size) {
    int max = -32768;
    for (int i = 0; i < size; i++) {
        if (a[i] > max) {
            max = a[i];
        }
    }
    return max;
}

void count_Sort(int a[], int size) {
    int n = max(a, size);
    int* h;
    h = new int[n + 1];
    for (int i = 0; i < n + 1; i++) {
        h[i] = 0;
    }
    for (int i = 0; i < size; i++) {
        h[a[i]]++;
    }
    int i = 0;
    int j = 0;
    while (j < n + 1) {
        if (h[j] > 0) {
            a[i++] = j;
            h[j]--;
        }
        else {
            j++;
        }
    }
    delete[] h;
}

int main() {
    int A[] = { 2, 5, 8, 12, 3, 6, 7, 10 };
    int n = sizeof(A) / sizeof(A[0]);
    count_Sort(A, n);
    for (int i = 0; i < n; i++) {
        cout << A[i] << " ";
    }

    return 0;
}
