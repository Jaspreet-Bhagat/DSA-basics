#include<iostream>
using namespace std;

void swap(int* x, int* y) {
    int temp = *x;
    *x = *y;
    *y = temp;
}

void selection_sort(int a[], int n) {
    for (int i = 0; i < n - 1; i++) {
        int k = i;
        for (int j = i + 1; j < n; j++) {
            if (a[j] < a[k]) {
                k = j;
            }
        }
        swap(&a[i], &a[k]);
    }
}

void display(int a[], int size) {
    for (int i = 0; i < size; i++) {
        cout << a[i] << " ";
    }
    cout << endl;
}

int main() {
    int a[] = {11, 13, 7, 12, 16, 9, 24, 5, 10, 3};
    int size = sizeof(a) / sizeof(a[0]);

    selection_sort(a, size);
    display(a, size);

    return 0;
}
