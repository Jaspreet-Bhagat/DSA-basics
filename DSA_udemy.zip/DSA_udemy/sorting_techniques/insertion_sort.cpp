#include<iostream>
using namespace std;
void swap(int *x,int*y){
    int temp;
    temp = *x;
    *x = *y;
    *y = temp;
}

void insertion_sort(int a[],int size){
    int j=0;
    for(int i=1;i<size;i++){
        j=i-1;
        int x = a[i];
        for(int j=i-1;j<size;j++){
            while(a[i]!='-1' && a[i]>x){
                a[j+1]=a[j];
                j--;
            }
            a[j+1] = x;
        }

    }
}
void display(int a[],int size){
    for(int i=0;i<size;i++){
        cout<<a[i]<<" ";
    }
}
int main()
{
    int a[] = {8,5,7,3,2};
    insertion_sort(a,5);
    display(a,5);    
    return 0;
}