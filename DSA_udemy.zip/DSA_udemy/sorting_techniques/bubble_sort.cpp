#include<iostream>
using namespace std;
void swap(int *x,int*y){
    int temp;
    temp = *x;
    *x = *y;
    *y = temp;
}
void bubble_sort(int a[],int size){
    int flag;
    for(int i=0;i<size-1;i++){
        flag =0;
        for(int j=0;j<size-1-i;j++){
            if(a[j]>a[j+1]){
                swap(a[j],a[j+1]);
                flag = 1;
            }
        }
        if(flag==0){
            break;
        }
    }
}
void display(int a[],int size){
    for(int i=0;i<size;i++){
        cout<<a[i]<<" ";
    }
}
int main()
{
    int a[] = {8,5,7,3,2};
    bubble_sort(a,5);
    display(a,5);    
    return 0;
}