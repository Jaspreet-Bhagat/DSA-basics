#include<iostream>
using namespace std;
void merge(int a[],int b[],int m,int n){
    int i,j,k;
    i=j=k=0;
    int c[m+n];
    while(i<m && j<n){
        if(a[i]<b[j]){
            c[k++] = a[i++];
        }else{
            c[k++] = b[j++];
        }
    }
    for(;i<m;i++){
        c[k++] = a[i];
    }
    for(;j<n;j++){
        c[k++] = b[j];
    }
    for(int i=0;i<m+n;i++){
        cout<<c[i]<<" ";
    }

}
void MergeSingle(int a[],int l,int mid,int h){
    int i,j,k;
    i=l;
    j = mid+1;
    k=l;
    int b[h+1];
    while(i<=mid && j<=h){
        if(a[i]<a[j]){
            b[k++]=a[i++];
        }else{
            b[k++]=a[j++];
        }
    }
    while (i <= mid){
        b[k++] = a[i++];
    }
    while (j <= h){
        b[k++] = a[j++];
    }
    for (int i=l; i<=h; i++){
        a[i] = b[i];
    }
    // for(int k = 0;k<h+1;k++){
    //     cout<<b[k]<<" ";
    // }
    
}

void iterative_merge_sort(int a[],int n){

    int i,j,k,p,l,h,mid;
    for(p=2;p<=n;p=p*2){
        for(i=0;i+p-1<n;i=i+p){
            l = i;
            h = i+p-1;
            mid = (l+h)/2;
            MergeSingle(a,l,mid,h);
        }

    }
    if(p/2<n){
        MergeSingle(a,0,p/2-1,n-1);
    }
}
void recursive_merge_sort(int a[],int l,int h){
    int mid;
    if(l<h){
        mid = (l+h)/2;
        recursive_merge_sort(a,l,mid);
        recursive_merge_sort(a,mid+1,h);
        MergeSingle(a,l,mid,h);
    }
}

int main()
{
    // int a[] ={2,10,18,20,23};
    // int b[] = {4,9,19,25};
    // int D[] = {2, 5, 8, 12, 3, 6, 7, 10};
    // MergeSingle(D, 0, 3, 7);
    int a[] = {11,13,7,12,16,9,24,5,10,3};
    int n=10;
    int i;
    // iterative_merge_sort(a,10);
    recursive_merge_sort(a,0,n);
    for(i=0;i<10;i++){
        cout<<a[i]<<" ";
    }
    return 0;
}