#include<iostream>
using namespace std;

void swap(int* x, int* y) {
    int temp = *x;
    *x = *y;
    *y = temp;
}
int partition(int a[],int l,int h){
    int i=l;
    int j = h;
    int pivot = a[l];
    do{
        do{i++;}while(a[i]<=pivot);
        do{j--;}while(a[j]>pivot);
        if(i<j)swap(&a[i],&a[j]);
    }while(i<j);
    swap(&a[l],&a[j]);
    return j;
}
void quick_sort(int a[],int l,int h){
    int j;
    if(l<h){
        j = partition(a,l,h);
        quick_sort(a,l,j);
        quick_sort(a,j+1,h);
    }
}
void display(int a[], int size) {
    for (int i = 0; i < size; i++) {
        cout << a[i] << " ";
    }
    cout << endl;
}

int main() {
    int a[] = {11, 13, 7, 12, 16, 9, 24, 5, 10, 3};
    int size = sizeof(a) / sizeof(a[0]);
    quick_sort(a,0,10);
    display(a, size);

    return 0;
}
