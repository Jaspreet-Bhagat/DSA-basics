 #include<iostream>
 using namespace std;
 void shell_Sort(int a[],int n){
   int gap,i,j;
   int temp;
   for(gap = n/2;gap>=1;gap/=2){
      for(i=gap;i<n;i++){
         temp = a[i];
         j = i-gap;
         while(j>=0 &&a[j]>temp){
            a[j+gap] = a[j];
            j= j-gap;
         }
         a[j+gap] = temp;
      }
   }
 }
 int main()
 {
   int a[]= {11,13,7,12,16,9,24,5,10,3};
   shell_Sort(a,10);
   for(int i=0;i<10;i++){
      cout<<a[i]<<" ";
   }
    
    return 0;
 }