#include<iostream>
#include<queue>
#include<stack>
using namespace std;
class node{
    public:
    node *lchild;
    int data;
    node *rchild;
};
class tree{
private:
    node *root;
public:
    tree();
    ~tree();
    void createTree();
    void preorder(node *p);
    void preorder(){ preorder(root);}
    void inorder(node *p);
    void inorder(){inorde(root);}
    void postorder(node *p);
    void postorder(){postorder(root);}
    void levelorder(node *p);
    void levelorder(){levelorder(root);}
    void iterativepreorder(node *p);
    void iterativepreorder(){ iterativepreorder(root);}
    void iterativeInorder(node *p);
    void iterativeInorder(){ iterativeInorder(root);}
    void iterativepostorder(node *p);
    void iterativepostorder(){ iterativepostorder(root);}
};
tree::tree(){
    root = NULL;
}
tree::~tree(){
    delete root;
}
void tree::createTree(){
    node *p;
    node *t;
    int x;
    queue<node*>q;
    root->data = 
}
int main()
{
    
    return 0;
}