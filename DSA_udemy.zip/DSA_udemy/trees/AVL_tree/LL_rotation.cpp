// balance_Factor = height of left subtree - left of right subtree/
// bf =|hl-hr|<= 1{-1,0,1}  :-balanced
// bf =|hl-hr|> 1:- imbalanced
#include<iostream>
using namespace std;
struct node{
    struct node *lchild;
    int data;
    int height;//we need balance factor that why we include the height in this.
    struct node *rchild;
}*root = NULL;
//to get the height:-
int getheight(struct node *p){
    if(p==NULL){
        return 0;
    }
    return p->height;
}
//for creating the node: - 
struct node * create(int key){
    struct node *temp = new node;
    temp->data = key;
    temp->lchild=temp->rchild = NULL;
    temp->height = 1;//when ever we are creating a new node , it will be having a height of 1 (ofcourse!).
    return temp;
}
int max(int a,int b){
    return a>b?a:b;
}
int getbalance(struct node *p){
    if(p==NULL){
        return 0;
    }else{
        return getheight(p->lchild)-getheight(p->rchild);
    }
}
struct node * rightrotation(struct node *p){
    struct node *temp = p->lchild;
    struct node *q = temp->rchild;
    temp->rchild = p;
    p->lchild = q;
    p->height = max(getheight(p->rchild),getheight(p->lchild))+1;
    temp->height = max(getheight(temp->rchild),getheight(temp->lchild)+1);
    return p;
}
struct node * leftrotate(struct node *p){
    struct node *temp = p->rchild;
    struct node *q = temp->lchild;
    temp->lchild = p;
    p->rchild = q;
    p->height = max(getheight(p->rchild),getheight(p->lchild)+1);
    temp->height = max(getheight(temp->rchild),getheight(temp->lchild)+1);
    return p;
} 
struct node *insert(struct node * node,int key){
    if(node == NULL){
        return(create(key));
    }
    if(key<node->data)
        node->lchild = insert(node->lchild,key);
    else if(key>node->data)
        node->rchild = insert(node->rchild,key);
        return node;

    node->height = 1+max(getheight(node->lchild),getheight(node->rchild));
    int bf = getbalance(node);
    //ll
    if(bf>1 && key< node->lchild->data){
        return rightrotation(node);
    }
    //rr
    if(bf>1 &&key>node->lchild->data){
        return leftrotate(node);
    }
    //lr
    if(bf>1 && key>node->lchild->data){
        node->lchild = leftrotate(node->lchild);
        return rightrotation(node);
    }
    //rl
    if(bf<-1 && key<node->rchild->data){
        node->rchild = rightrotation(node->rchild);
        return leftrotate(node);
    }
    return node;
}
void preorder(struct node *p){
    if(p){
        cout<<p->data<<" ";
        preorder(p->lchild);
        preorder(p->rchild);
    }
}
int main()
{

    struct node * root = NULL;
    root = insert(root,1);
    root = insert(root,2);
    root = insert(root,4);
    root = insert(root,5);
    root = insert(root,6);
    root = insert(root,3);
    preorder(root);
    return 0;
}