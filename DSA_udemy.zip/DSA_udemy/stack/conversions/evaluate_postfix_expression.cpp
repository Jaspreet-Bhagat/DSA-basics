#include<iostream>
using namespace std;

class node {
    int data;
    node* next;

public:
    node() {
        data = 0;
        next = NULL;
    }

    int isfull();
    int isempty();
    void push(int item);
    int pop();
    int isoperand(char x);
    int pre(char x);
    int eval(char* postfix);
};

int node::isfull() {
    node* temp;
    temp = new node;
    if (temp == NULL) {
        return 1;
    } else {
        return 0;
    }
}

int node::isempty() {
    if (next == NULL) {
        return 1;
    } else {
        return 0;
    }
}

int node::pre(char x) {
    if (x == '+' || x == '-') {
        return 1;
    } else if (x == '*' || x == '/') {
        return 2;
    }
    return 0; // Added a default return statement
}

int node::isoperand(char x) {
    if (x == '+' || x == '-' || x == '*' || x == '/') {
        return 1;
    } else {
        return 0;
    }
}

int node::pop() {
    int x = -1;
    if (isempty()) {
        cout << "Stack is empty!" << endl;
    } else {
        node* p = next;
        next = next->next;
        x = p->data;
        delete p;
    }
    return x;
}

void node::push(int item) {
    if (isfull()) {
        cout << "Stack is full!" << endl;
    } else {
        node* temp = new node;
        temp->data = item;
        temp->next = next;
        next = temp;
    }
}

int node::eval(char* postfix) {
    int i = 0;
    int x1, x2, r;
    for (i = 0; postfix[i] != '\0'; i++) {
        if (isoperand(postfix[i])) {
            push(postfix[i] - '0');
        } else {
            x2 = pop();
            x1 = pop();
            switch (postfix[i]) {
                case '+': r = x1 + x2; break;
                case '-': r = x1 - x2; break;
                case '*': r = x1 * x2; break;
                case '/': r = x1 / x2; break;
            }
            push(r);
        }
    }
    return next->data;
}

int main() {
    const char* postfix = "234*+82/-";
    node stack;
    cout << "Result is: " << stack.eval(const_cast<char*>(postfix)) << endl;
    return 0;
}
