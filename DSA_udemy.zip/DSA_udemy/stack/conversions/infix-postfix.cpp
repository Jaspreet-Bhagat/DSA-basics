#include<iostream>
#include<stdio.h>
#include<cstring>
using namespace std;
struct node{
    int data;
    struct node *next;
}*top =NULL;
int isempty(){
    if(top==NULL){
        return 1;
    }else{
        return 0;
    }
}
int isfull(){
    struct node *temp;
    temp = new node;
    if(temp==NULL){
        return 1;
    }else{
        return 0;
    }
}
void push(char exp){
    struct node *temp;
    if(isfull()){
        cout<<"stack is full!"<<endl;
    }else{
        temp = new node;
        temp->data = exp;
        temp->next = top;
        top = temp;
    }
}
int pop(){
    int x = -1;
    if(isempty()){
        cout<<"stack is empty!"<<endl;
    }else{
        struct node *temp = top;
        top = top->next;
        x = temp->data;
    }
    return x;
}
int stacktop(){
    if(isempty()){
        cout<<"stack is empty!"<<endl;
    }else{
        return top->data;
    }
}
int isoperand(char x){
    if(x == '+' || x == '-' || x == '*' || x == '/'){
        return 0;
    }else{
        return 1;
    }
}
int pre(char x){
    if(x == '+' || x =='-'){
        return 1;
    }else if(x == '*' || x == '/'){
        return 2;
    }
    return 0;
}
char *convert(const char * infix){
    char *postfix;
    int i=0,j=0;
    postfix = new char[strlen(infix)+1];
    while(infix[i]!='\0'){
        if(isoperand(infix[i])){
            postfix[j++] = infix[i++];
        }else{
            if(pre(infix[i])>pre(top->data)){
                push(infix[i++]);
            }else{
                postfix[j++] = pop();
            }
        }
    }
    while(top!=NULL){
        postfix[j++]=pop();
    }
    postfix[j] = '\0';
    return postfix;
}
int main()
{
    const char *infix = "a+b*c";
    push('#');
    char *postfix = convert(infix);
    cout<<postfix;
    
    return 0;
}