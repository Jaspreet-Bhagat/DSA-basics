#include<iostream>
using namespace std;
struct node{
    int data;
    struct node *next;
}*top = NULL;
int isfull(){
    struct node *t;
    t = new node;
    if(t==NULL){
        return 1;
    }else{
        return 0;
    }
}
int isempty(){
    if(top==NULL){
        return 1;
    }else{
        return 0;
    }
}
void push(int item){
    if(isfull()){
        cout<<"stack overflow!"<<endl;
    }else{
        struct node *t = new node;
        t->data = item;
        t->next = top;
        top = t;
    }
}
int pop(){
    int x = -1;
    if(isempty()){
        cout<<"stack underflow!"<<endl;
    }else{
        struct node *p = top;
        top = top->next;
        x = p->data;
        // p->next = NULL;
        delete []p;
    }
     return x;
}
int peek(int pos){
    if(isempty()){
        cout<<"stack underflow!"<<endl;
    }else{
        struct node*p = top;
        for(int i=0;i&&i<pos-1;i++){
            p =p->next;
        }
        if(p!=NULL){
            return p->data  ;
        }else{
            return -1;
        }
    }
}
int stacktop(){
    if(top!=NULL){
        return top->data;
    }else{
        return -1;
    }
}
void display(){
    struct node *p;
    p = top;
    while(p!=NULL){
        cout<<p->data<<" ";
        p = p->next;
    }
    cout<<endl;
}
int main()
{
    push(10);
    push(20);
    push(30);
    display();
    cout<<"popped: "<<pop();
    return 0;
}