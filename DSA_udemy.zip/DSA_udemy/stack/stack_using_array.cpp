#include<iostream>
using namespace std;
class stack{
    int top;
    int size;
    int *a;
    public:
    stack(int size);
    int pop();
    void push(int x);
    int peek(int index);
    int isfull();
    int isempty();
    void display();
    int stacktop();
};
stack::stack(int size){
        Top = -1;
        this->size = size;
        a=new int[this->size];
    }
int stack::isempty(){
    if(top==-1){
        return 1;
    }else{
        return 0;
    }
}
stack::~stack(){
    delete []a;
}
int stack::isfull(){
    if(top==size-1){
        return 1;
    }else{
        return 0;
    }
}
int stack::stacktop(){
    if(isempty()){
        return -1;
    }
    return a[top];
}
int stack::peek(int index){
    int x = -1;
    if(top-index+1 < 0 || top-index+1==size){//3-1+1=3
        cout<<"invalid position!"<<endl;
    }else{
        x = s[top-index+1];
    }
    return x;
}
void stack::push(){
    if(isfull()){
        cout<<"the stack is overflow!"<<endl;
    }else{
        top++;
        a[top] = item;
    }
}
int stack::pop(){
    int x = 1;
    if(isempty()){
        cout<<"the stack underflow!"<<endl;
    }else{
        x = s[top];
        top--;
    }
    return x;
}
void display(){
    for(i=top-1;i>=0;i--){
        cout<<a[i]<<" | "<<flush;
    }
    cout<<endl;
}
int main()
{
    int A[] = {1, 3, 5, 7, 9};
 
    Stack stk(sizeof(A)/sizeof(A[0]));
 
    // Populate stack with array elements
    for (int i=0; i<sizeof(A)/sizeof(A[0]); i++){
        stk.push(A[i]);
    }
    stk.push(11);
 
    cout << "Stack full: " << stk.isFull() << endl;
 
    // Display stack;
    cout << "Stack: " << flush;
    stk.display();
 
    // Peek
    cout << "Peek at 0th: " << stk.peek(0) << endl;
    cout << "Peek at 3rd: " << stk.peek(3) << endl;
    cout << "Peek at 10th: " << stk.peek(10) << endl;
 
    // Top element
    cout << "Top element: " << stk.stackTop() << endl;
 
    // Pop out elements from stack
    cout << "Popped out elements: " << flush;
    for (int i=0; i<sizeof(A)/sizeof(A[0]); i++){
        cout << stk.pop() << ", " << flush;
    }
    cout << endl;
    stk.pop();
 
    cout << "Stack empty: " << stk.isEmpty() << endl;
    
    return 0;
}
