#include<iostream>
#include<cstring>
#include<map>

using namespace std;
class stack{
    int top;
    int size;
    char *a;
    public:
    stack(int size);
    ~stack();
    char pop();
    void push(int x);
    int isfull();
    int isempty();
    void display();
    int stacktop();
    bool isBalance(char *exp);
};
stack::stack(int size){
        top = -1;
        this->size = size;
        a=new char[this->size];
    }
int stack::isempty(){
    if(top==-1){
        return 1;
    }else{
        return 0;
    }
}
stack::~stack(){
    delete []a;
}
int stack::isfull(){
    if(top==size-1){
        return 1;
    }else{
        return 0;
    }
}
void stack::push(int item){
    if(isfull()){
        cout<<"the stack is overflow!"<<endl;
    }else{
        top++;
        a[top] = item;
    }
}
char stack::pop(){
    int x = 1;
    if(isempty()){
        cout<<"the stack underflow!"<<endl;
    }else{
        x = a[top];
        top--;
    }
    return x;
}
void stack::display(){
    for(int i=top-1;i>=0;i--){
        cout<<a[i]<<" | "<<flush;
    }
    cout<<endl;
}
// bool stack::isBalance(char *exp){
//     stack stk(strlen(exp));
//     for(int i=0;i<strlen(exp);i++){
//         if(exp[i]=='(')
//             stk.push(exp[i]);
//         else if(exp[i]==')'){
//                       // ) and stack is empty: Unbalanced expression
//             if(stk.isempty()){
//                 return false;
//             }else{
//                 stk.pop();
//             }
//         }
//     }
//     return stk.isempty()?true:false;
// }
int stack::stacktop(){
    if(isempty()){
        return -1;
    }
    return a[top];
}
bool stack::isBalance(char *exp){
    map<char,char> mapping;
    mapping['}'] = '{';
    mapping[')'] = '(';
    mapping[']'] = '[';
    map<char,char>::iterator itr;
    stack stk(strlen(exp));
    for(int i=0;i<strlen(exp);i++){
        if(exp[i]=='{' || exp[i]=='(' || exp[i]=='['){
            stk.push(exp[i]);
        }else if(exp[i]=='}' || exp[i]==')' || exp[i]==']'){
            if(stk.isempty()){
                return false;
            }else{
                char temp = stk.stacktop();
                itr = mapping.find(exp[i]);
                if(temp == itr->second){
                    stk.pop();
                }else{
                    return false;
                }
            }

        }
    }
    return stk.isempty() ? true:false;
}
int main(){
    stack obj(15);
    char A[] = "{([a+b]*[c-d])/e}";
    cout << obj.isBalance(A) << endl;
 
    char B[] = "{([a+b]}*[c-d])/e}";
    cout << obj.isBalance(B) << endl;
 
    char C[] = "{([{a+b]*[c-d])/e}";
    cout << obj.isBalance(C) << endl;
    return 0;
}