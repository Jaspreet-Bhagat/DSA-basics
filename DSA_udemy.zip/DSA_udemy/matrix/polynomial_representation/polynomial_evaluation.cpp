#include <iostream>
using namespace std;

class Term {
public:
    int coeff;
    int exp;
};

class Poly {
public:
    int n;
    Term* terms;

    Poly(int size) {
        n = size;
        terms = new Term[n];
    }

    ~Poly() {
        delete[] terms;
    }

    void create();
    void display();
    Poly* add(Poly* p);
};

void Poly::create() {
    cout << "Number of terms? ";
    cin >> n;

    terms = new Term[n];

    cout << "Enter terms:" << endl;
    for (int i = 0; i < n; i++) {
        cin >> terms[i].coeff >> terms[i].exp;
    }
}

void Poly::display() {
    for (int i = 0; i < n; i++) {
        cout << terms[i].coeff << "x^" << terms[i].exp;
        if (i != n - 1) {
            cout << " + ";
        }
    }
    cout << endl;
}

Poly* Poly::add(Poly* p) {
    int i, j, k;
    Poly* sum = new Poly(n + p->n);

    i = j = k = 0;

    while (i < n && j < p->n) {
        if (terms[i].exp > p->terms[j].exp) {
            sum->terms[k++] = terms[i++];
        } else if (terms[i].exp < p->terms[j].exp) {
            sum->terms[k++] = p->terms[j++];
        } else {
            sum->terms[k].exp = terms[i].exp;
            sum->terms[k++].coeff = terms[i++].coeff + p->terms[j++].coeff;
        }
    }

    for (; i < n; i++) {
        sum->terms[k++] = terms[i];
    }

    for (; j < p->n; j++) {
        sum->terms[k++] = p->terms[j];
    }

    sum->n = k;
    return sum;
}

int main() {
    Poly p1(0), p2(0), *p3;

    p1.create();
    p2.create();

    p3 = p1.add(&p2);

    cout << endl;
    p1.display();
    cout << endl;
    p2.display();
    cout << endl;
    p3->display();

    delete p3;

    return 0;
}
