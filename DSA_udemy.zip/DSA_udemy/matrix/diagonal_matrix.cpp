#include<iostream>
using namespace std;
class Array{
    int *a;
    int size;
public :
    Array(){
        size = 2;
        a = new int[2];
    }
    Array(int size){
        this->size = size;
        a = new int [this -> size];
    }
    ~Array(){
        delete [] a;
    }
    void set(int i,int j,int x){
        if(i == j){
            a[i-1] = x;
        }
    }
    int get(int i,int j){
        if(i==j){
            return a[i-1];
        }
        else{
            return 0;
        }
    }
    void display(){
        for(int i=0;i<size;i++){
            for(int j=0;j<size;j++){
                if(i==j){
                    cout<<""<<a[i]<<" ";
                }
                else{
                    cout<<"0 ";
                }
            }
            cout<<"\n";
        }
    }
};
int main()
{
    Array obj(4);
    obj.set(1,1,5);
    obj.set(2,2,8);
    obj.set(3,3,9);
    obj.set(4,4,12);
    obj.display();
    cout<<obj.get(1,3);
    return 0;
}