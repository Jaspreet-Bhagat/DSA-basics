#include<iostream>
using namespace std;

class Array {
    int *a;
    int size;

public:
    Array() {
        size = 2;
        a = new int[2*(2+1)/2];
    }

    Array(int size) {
        this->size = size;
        a = new int[size*(size+1)/2];
    }

    ~Array() {
        delete[] a;
    }

    void set(int i, int j, int x) {
        if (i <= j) {
            a[(size*(i-1) - ((i-2)*(i-1))/2) + (j-i)] = x;
        }
    }

    int get(int i, int j) {
        if (i <= j) {
            return a[(size*(i-1) - ((i-2)*(i-1))/2) + (j-i)];
        }
        return 0;
    }

    void display() {
        for (int i = 1; i <= size; i++) {
            for (int j = 1; j <= size; j++) {
                if (i <= j) {
                    cout << a[(size*(i-1) - ((i-2)*(i-1))/2) + (j-i)] << " ";
                } else {
                    cout << "0 ";
                }
            }
            cout << endl;
        }
    }
};

int main() {
    int d;
    cout << "Enter dimensions:" << endl;
    cin >> d;
    Array obj(d);
    int x;
    cout << "Enter all elements: ";
    for (int i = 1; i <= d; i++) {
        for (int j = 1; j <= d; j++) {
            cin >> x;
            obj.set(i, j, x);
        }
    }
    obj.display();
    return 0;
}
