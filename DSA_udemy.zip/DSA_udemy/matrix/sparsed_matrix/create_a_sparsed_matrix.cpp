#include<iostream>
using namespace std;
class element{
    public:
        int row_no;
        int col_no;
        int item;
};
class sparse{
    int T_row;
    int T_col;
    int T_num;
    element *e;
    public:
    sparse(int m,int n,int num){
        this->T_row = m;
        this->T_col = n;
        this->T_num = num;
        e = new element[this->T_num];
    }
    ~sparse(){
        delete []e;
    }
    sparse operator +(sparse &s);
    friend istream  & operator>>(istream &is,sparse &s);
    friend ostream  & operator<<(ostream &os,sparse &s);
};
sparse sparse::operator +(sparse &s){
    int i,j,k;
    if(T_row != s.T_row && T_col != s.T_col){
        return sparse(0,0,0);
    }
    sparse *sum = new sparse(T_row,T_col,T_num+s.T_num);
    i=j=k=0;
    while(i<T_num && j<s.T_num){
        if(e[i].row_no <s.e[j].row_no){
            sum->e[k++]= e[i++];
        }else if(e[i].row_no>s.e[j].row_no){
            sum->e[k++] = s.e[j++];
        }else{
            if(e[i].col_no <s.e[j].col_no){
                sum->e[k++]= e[i++];
            }else if(e[i].col_no>s.e[j].col_no){
                sum->e[k++] = s.e[j++];
            }else{
                sum->e[k] = e[i];
                sum->e[k++].item = e[i++].item+s.e[j++].item;
            }
        }
    }
        for(;i<T_num;i++){
            sum->e[k++]= e[i];
        }
        for(;j<s.T_num;j++){
            sum->e[k++]= s.e[j];
        }
        sum->T_num = k;
        return *sum;
}
istream  & operator>>(istream &is,sparse &s){
    cout<<"enter non-Zero element: "<<endl;
    for(int i=0;i<s.T_num;i++){
        cin>>s.e[i].row_no;
        cin>>s.e[i].col_no;
        cin>>s.e[i].item;
    }
}
ostream  & operator<<(ostream &os,const sparse &s){
    int k=0;
    for(int i=0;i<s.T_row;i++){
        for(int j=0;j<s.T_col;j++){
            if(s.e[k].row_no == i && s.e[k].col_no == j){
                os<<s.e[k++].item<<" ";
            }
            else{
                os<<"0 ";
            }
        }
        os<<endl;
    }
    return os;
}
int main()
{
    sparse s1(5,5,5);
    sparse s2(5,5,5);
    cin>>s1;
    cin>>s2;
    sparse sum=s1+s2;
    cout<<"First Matrix"<<endl<<s1;
    cout<<"Second MAtrix"<<endl<<s2;
    cout<<"Sum Matrix"<<endl<<sum;
    return 0;
}